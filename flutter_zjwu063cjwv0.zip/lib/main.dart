import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
// import flutter material design
// text, container, scaffold, appbar and etc.
void main() { 
  // starting point of every dart file
  runApp(const SimplePortfolioApp());
  // Flutter function that launch our application
  // function - standalone block of code
  // method - function that define w/in a class operates on objects data
  // 
  // MyApp() - your application

}

class SimplePortfolioApp extends StatelessWidget {
  const SimplePortfolioApp({Key? key}) :super(key: key);

@override
Widget build (BuildContext context) {
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Portfolio',
    home: HomePage(),
  );
}
}

class HomePage extends StatefulWidget {


@override
State<HomePage> createState() => _HomePageState();
}
// State - returns the object
// State for the Homepage
// createState - Method
// _HomePageState() - hold data that can change, trigger rebuild our application

// ... (Keep your imports and main function the same)

class _HomePageState extends State<HomePage> {
  String selectedPage = 'Home';
  late ScrollController _scrollController;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
  }

  // logic to switch between sections
  Widget _buildContent() {
    switch (selectedPage) {
      case 'Home':
        return _buildHomeSection();
      case 'About':
        return _buildAboutSection();
      case 'Skills':
        return _buildSkillsSection();
      case 'Contact':
        return _buildContactSection();
      default:
        return _buildHomeSection();
    }
  }

  // --- SECTION WIDGETS ---

  Widget _buildHomeSection() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ClipOval(
          child: Container(
            color: Colors.grey[300], // Placeholder if image is missing
            child: Image.asset(
              'lib/assets/images/profile.png',
              width: 120,
              height: 120,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => 
                Icon(Icons.person, size: 80, color: Colors.grey),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          'Rhian Dustin Cruz',
          style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Text(
          'Flutter Developer',
          style: GoogleFonts.roboto(fontSize: 16, color: Colors.grey[600]),
        ),
      ],
    );
  }

  Widget _buildAboutSection() {
    return Column(
      children: [
        Text('About Me', style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Text(
          'I am a passionate developer dedicated to building Games that involves beautiful Uis and a smooth user experiences',
          textAlign: TextAlign.center,
          style: GoogleFonts.roboto(fontSize: 16, height: 1.5),
        ),
      ],
    );
  }

  Widget _buildSkillsSection() {
    final List<String> skills = ['Flutter', 'Dart', 'C#', 'Git', 'Java', 'Godot'];
    return Column(
      children: [
        Text('Technical Skills', style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          alignment: WrapAlignment.center,
          children: skills.map((skill) => Chip(
            label: Text(skill),
            backgroundColor: Colors.blue.withOpacity(0.1),
            side: const BorderSide(color: Colors.blue),
          )).toList(),
        ),
      ],
    );
  }

  Widget _buildContactSection() {
    return Column(
      children: [
        Text('Get In Touch', style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        const ListTile(
          leading: Icon(Icons.email, color: Colors.blue),
          title: Text('rdustincruz@gmail.com'),
        ),
        const ListTile(
          leading: Icon(Icons.location_on, color: Colors.blue),
          title: Text('Tinajeros, Malabon'),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5), // Fixed hex color
      appBar: AppBar(
        title: Text('Portfolio', style: GoogleFonts.poppins(fontSize: 20, fontWeight: FontWeight.w600)),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(color: Colors.blue),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  const CircleAvatar(
                  radius: 30,
                  backgroundImage: AssetImage('lib/assets/images/profile.png'),
                  ),
                  SizedBox(height: 4),
                  Text('Cruz Rhian Dustin N.', style: TextStyle(color: Colors.white, fontSize: 18)),
                  SizedBox(height: 4),
                  Text('Flutter Developer', style: TextStyle(color: Colors.white70)),
                ],
              ),
            ),
            _drawerTile('Home', Icons.home),
            _drawerTile('About', Icons.person),
            _drawerTile('Skills', Icons.lightbulb),
            _drawerTile('Contact', Icons.email),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.download, color: Colors.blue),
              title: const Text('Download Resume'),
              onTap: () => Navigator.pop(context),
            )
          ],
        ),
      ),
      body: SingleChildScrollView(
        controller: _scrollController,
        child: Padding(
          padding: const EdgeInsets.all(40.0), // Increased padding for better look
          child: Center(child: _buildContent()),
        ),
      ),
    );
  }

  // Helper to keep the Drawer code dry
  Widget _drawerTile(String title, IconData icon) {
    return ListTile(
      leading: Icon(icon, color: Colors.blue),
      title: Text(title),
      selected: selectedPage == title,
      onTap: () {
        Navigator.pop(context);
        setState(() => selectedPage = title);
      },
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}



